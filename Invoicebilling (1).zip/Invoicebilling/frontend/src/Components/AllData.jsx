import React, { useEffect, useState } from 'react';
import axios from 'axios';

const AllInvoicesWithFilters = () => {
  const [invoices, setInvoices] = useState([]);
  const [filteredInvoices, setFilteredInvoices] = useState([]);
  const [expandedInvoice, setExpandedInvoice] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');


  const [searchTerm, setSearchTerm] = useState('');
  const [paymentModes, setPaymentModes] = useState([]);
  const [selectedPaymentMode, setSelectedPaymentMode] = useState('');
  const [itemsList, setItemsList] = useState([]);
  const [selectedItem, setSelectedItem] = useState('');
  const [sortOrder, setSortOrder] = useState('asc');

  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 5;

  useEffect(() => {
    const fetchInvoices = async () => {
      try {
        setLoading(true);
        const res = await axios.get('http://localhost:5000/api/invoices/all');
        setInvoices(res.data);
        setFilteredInvoices(res.data);

        const modes = Array.from(new Set(res.data.map(inv => inv.totals?.paymentMode))).filter(Boolean);
        setPaymentModes(modes);

        const items = Array.from(
          new Set(res.data.flatMap(inv => inv.items.map(item => item.pname)))
        ).filter(Boolean);
        setItemsList(items);
      } catch (err) {
        console.error('Failed to fetch invoices:', err);
        setError('Error fetching invoices');
      } finally {
        setLoading(false);
      }
    };

    fetchInvoices();
  }, []);

  useEffect(() => {
    let filtered = invoices;

    if (searchTerm) {
      filtered = filtered.filter(
        inv =>
          inv.customer?.cname?.toLowerCase().includes(searchTerm.toLowerCase()) ||
          inv.invoiceNumber?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (selectedPaymentMode) {
      filtered = filtered.filter(
        inv => inv.totals?.paymentMode?.toLowerCase() === selectedPaymentMode.toLowerCase()
      );
    }

    if (selectedItem) {
      filtered = filtered.filter(
        inv => inv.items?.some(item => item.pname?.toLowerCase() === selectedItem.toLowerCase())
      );
    }


    // Sort based on invoice number
    filtered.sort((a, b) => {
      const numA = a.invoiceNumber?.toString().toLowerCase() || '';
      const numB = b.invoiceNumber?.toString().toLowerCase() || '';
      return sortOrder === 'asc' ? numA.localeCompare(numB) : numB.localeCompare(numA);
    });

    setFilteredInvoices(filtered);
    setCurrentPage(1); // Reset to first page on filter/sort change
  }, [searchTerm, selectedPaymentMode, selectedItem, invoices, sortOrder]);

  const toggleInvoice = (id) => {
    setExpandedInvoice(expandedInvoice === id ? null : id);
  };

  const totalSales = filteredInvoices.reduce((acc, inv) => acc + (inv.totals?.finalAmount || 0), 0);

  const totalPages = Math.ceil(filteredInvoices.length / itemsPerPage);
  const paginatedInvoices = filteredInvoices.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  return (
    <div className="container-fluid mt-5 mb-5">
      <div className="row">
        {/* Sidebar Filters */}
        <div className="col-md-2 mb-4">
          <div className="card shadow-sm p-3 h-100">
            <h5 className="mb-3 text-primary">🔍 Filters</h5>

            <div className="mb-3">
              <label className="form-label">Search</label>
              <input
                type="text"
                className="form-control"
                placeholder="Customer or Invoice #"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>

            <div className="mb-3">
              <label className="form-label">Payment Mode</label>
              <select
                className="form-select"
                value={selectedPaymentMode}
                onChange={(e) => setSelectedPaymentMode(e.target.value)}
              >
                <option value="">All</option>
                {paymentModes.map((mode, idx) => (
                  <option key={idx} value={mode}>{mode}</option>
                ))}
              </select>
            </div>

            <div className="mb-3">
              <label className="form-label">Item</label>
              <select
                className="form-select"
                value={selectedItem}
                onChange={(e) => setSelectedItem(e.target.value)}
              >
                <option value="">All</option>
                {itemsList.map((item, idx) => (
                  <option key={idx} value={item}>{item}</option>
                ))}
              </select>
            </div>

            <div className="mb-3">
              <label className="form-label">Sort by Invoice Number</label>
              <select
                className="form-select"
                value={sortOrder}
                onChange={(e) => setSortOrder(e.target.value)}
              >
                <option value="asc">Ascending</option>
                <option value="desc">Descending</option>
              </select>
            </div>
            <button
              className="btn btn-outline-secondary w-100 mt-2"
              onClick={() => {
                setSearchTerm('');
                setSelectedPaymentMode('');
                setSelectedItem('');
                setSortOrder('asc');
              }}
            >
              🔄 Clear Filters
            </button>
          </div>
        </div>

        {/* Main Content */}
        <div className="col-md-10 ps-4">
          <h4 className="text-center text-primary mb-4">🧾 All Invoices</h4>
          {loading ? (
            <p className="text-center text-muted">Loading invoices...</p>
          ) : error ? (
            <p className="text-danger text-center">{error}</p>
          ) : (
            <>
              <div className="row">
                {paginatedInvoices.map((inv) => {
                  const isCredit = inv.totals?.paymentMode?.toLowerCase() === 'credit';
                  return (
                    <div className="col-md-12 mb-4" key={inv._id}>
                      <div
                        className="card shadow-sm p-3"
                        style={{
                          cursor: 'pointer', transition: 'all 0.3s', borderLeft: isCredit ? '5px solid #ffc107' : '5px solid #28a745',
                          backgroundColor: '#f9f9f9',
                          borderRadius: '10px',
                        }}
                        onClick={() => toggleInvoice(inv._id)}
                      >
                        <div className="d-flex justify-content-between align-items-center">
                          <div>
                            <h6 className="mb-1 fw-bold">Invoice #{inv.invoiceNumber}</h6>
                            <small className="text-muted">{inv.date}</small>
                            <p className="mb-0">👤 {inv.customer?.cname || 'N/A'}</p>
                            <p className="fw-bold text-success">Grand Total : ₹ {inv.totals?.finalAmount?.toFixed(2) || '0.00'}</p>
                          </div>
                          <div className="text-end">
                            <div
                              className={`px-2 py-1 rounded-pill d-inline-block`}
                              style={{
                                backgroundColor: isCredit ? '#fff7cc' : '#d9fdd3',
                                color: isCredit ? '#b58900' : '#27632a',
                                fontWeight: 'bold',
                                borderRadius: '5px',
                                fontSize: '0.85rem'
                              }}
                            >
                              <span style={{
                                display: 'inline-block',
                                width: '8px',
                                height: '8px',
                                borderRadius: '50%',
                                backgroundColor: isCredit ? '#b58900' : '#27632a',
                                marginRight: '6px'
                              }}></span>
                              {inv.totals.paymentMode}
                            </div>
                            <div className="mt-2 fs-5 text-primary">{expandedInvoice === inv._id ? '▼' : '›'}</div>
                          </div>
                        </div>

                        {expandedInvoice === inv._id && (
                          <div className="mt-3">
                            <p className="fw-bold mb-2">🧾 Items:</p>
                            <ul className="list-unstyled">
                              {inv.items.map((item, idx) => (
                                <li key={idx}>
                                  {item.pname} - {item.qty} x ₹{item.saleprice}
                                </li>
                              ))}
                            </ul>
                            <p className="fw-bold mt-3">Grand Total: ₹ {inv.totals?.finalAmount?.toFixed(2) || '0.00'}</p>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
                {paginatedInvoices.length === 0 && (
                  <p className="text-center">No invoices found for selected filters.</p>
                )}
              </div>

              {/* Pagination Controls with Page Numbers */}
              {totalPages > 1 && (
                <div className="d-flex justify-content-center align-items-center mt-3 flex-wrap gap-2">
                  {[...Array(totalPages)].map((_, idx) => (
                    <button
                      key={idx}
                      className={`btn ${currentPage === idx + 1 ? 'btn-primary' : 'btn-outline-primary'}`}
                      onClick={() => setCurrentPage(idx + 1)}
                    >
                      {idx + 1}
                    </button>
                  ))}
                </div>
              )}
              <button
                className="btn btn-success ms-3"
                onClick={() => {
                  const headers = ['Invoice Number', 'Customer', 'Date', 'Payment Mode', 'Final Amount'];
                  const rows = filteredInvoices.map(inv => [
                    inv.invoiceNumber,
                    inv.customer?.cname || '',
                    inv.date,
                    inv.totals?.paymentMode || '',
                    inv.totals?.finalAmount?.toFixed(2) || '0.00',
                  ]);
                  const csv = [headers, ...rows].map(row => row.join(',')).join('\n');
                  const blob = new Blob([csv], { type: 'text/csv' });
                  const url = URL.createObjectURL(blob);
                  const link = document.createElement('a');
                  link.href = url;
                  link.download = 'invoices.csv';
                  link.click();
                }}
              >
                📤 Export CSV
              </button>

              {/* Total Sales */}
              <div className="text-end mt-3 fw-bold">
                🔢 Total Sales: ₹ {totalSales.toFixed(2)}
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default AllInvoicesWithFilters;
