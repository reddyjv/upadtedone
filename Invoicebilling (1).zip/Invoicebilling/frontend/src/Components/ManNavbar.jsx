import React, { useEffect, useState, useRef } from 'react';

function Navbar({ onLogout }) {
    const [user, setUser] = useState(null);
    const [dropdownOpen, setDropdownOpen] = useState(false);
    const dropdownRef = useRef(null);

    useEffect(() => {
        const storedUser = localStorage.getItem('user');
        if (storedUser) {
            setUser(JSON.parse(storedUser));
        }

        // Close dropdown when clicking outside
        const handleClickOutside = (e) => {
            if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
                setDropdownOpen(false);
            }
        };
        document.addEventListener("mousedown", handleClickOutside);
        return () => {
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, []);

    const getInitials = (name) => {
        const first = name?.charAt(0)?.toUpperCase() || '';
        const second = name?.charAt(1)?.toUpperCase() || '';
        return first + second;
    };

    const initials = getInitials(user?.name);

    return (
        <nav className="navbar navbar-expand-lg navbar-light bg-light shadow-sm px-4 py-2 border-bottom">
            <div className="container-fluid d-flex justify-content-between align-items-center">
                {/* Left Side Title */}
                <div className="navbar-brand fw-bold">
                    <i className="bi bi-speedometer2 me-2 text-primary"></i>
                    {user?.role === "manager" ? "Manager Dashboard" : "Vendor Dashboard"}
                </div>

                {/* Right Side Search and Profile */}
                <div className="d-flex align-items-center gap-3">

                    {/* Search Bar */}
                    <div className="input-group input-group-sm" style={{ width: '180px' }}>
                        <input type="text" className="form-control" placeholder="Search..." />
                        <span className="input-group-text bg-primary text-white">
                            <i className="bi bi-search"></i>
                        </span>
                    </div>

                    {/* Profile Dropdown */}
                    {user && (
                        <div className="dropdown" ref={dropdownRef}>
                            <button
                                className="btn btn-light d-flex align-items-center border gap-2 rounded-pill px-1 py-1"
                                onClick={() => setDropdownOpen(!dropdownOpen)}
                            >
                                <div
                                    className="rounded-circle bg-primary text-white d-flex justify-content-center align-items-center"
                                    style={{
                                        width: '34px',
                                        height: '34px',
                                        fontWeight: 'bold',
                                        fontSize: '0.9rem'
                                    }}
                                >
                                    {initials}
                                </div>
                                <span className="fw-semibold">{user.name}</span>
                                <i className="bi bi-caret-down-fill small"></i>
                            </button>

                            {dropdownOpen && (
                                <ul className="dropdown-menu dropdown-menu-end show mt-2" style={{ position: 'absolute' }}>
                                    <li>
                                        <button className="dropdown-item">
                                            <i className="bi bi-person-lines-fill me-2 text-primary"></i>
                                            Manage Profile
                                        </button>
                                    </li>
                                    <li><hr className="dropdown-divider" /></li>
                                    <li>
                                        <button onClick={onLogout} className="dropdown-item text-danger">
                                            <i className="bi bi-box-arrow-right me-2"></i>
                                            Logout
                                        </button>
                                    </li>
                                </ul>
                            )}
                        </div>
                    )}
                </div>
            </div>
        </nav>
    );
}

export default Navbar;
