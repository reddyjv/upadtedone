import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Bar, Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap-icons/font/bootstrap-icons.css';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

const ManagerDashboard = () => {
  const [stats, setStats] = useState({
    products: 0,
    customers: 0,
    orders: 0,
    employees: 0,
  });
  const [chartData, setChartData] = useState({
    labels: [],
    products: [],
    customers: [],
    orders: [],
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const [productsRes, customersRes, ordersRes, employeesRes] = await Promise.all([
          axios.get('http://localhost:5000/api/products'),
          axios.get('http://localhost:5000/api/customers'),
          axios.get('http://localhost:5000/api/orders'),
          axios.get('http://localhost:5000/api/employees'),
        ]);

        setStats({
          products: Array.isArray(productsRes.data) ? productsRes.data.length : 5,
          customers: Array.isArray(customersRes.data) ? customersRes.data.length : 10,
          orders: Array.isArray(ordersRes.data) ? ordersRes.data.length : 0,
          employees: Array.isArray(employeesRes.data) ? employeesRes.data.length : 0,
        });

        // Fetch chart data
        const chartRes = await axios.get('http://localhost:5000/api/chart-data');
        setChartData(chartRes.data);
      } catch (error) {
        console.error('Error fetching data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchStats();
  }, []);

  const barChartData = {
    labels: chartData.labels,
    datasets: [
      {
        label: 'Products',
        data: chartData.products,
        backgroundColor: 'rgba(0, 123, 255, 0.6)',
      },
      {
        label: 'Customers',
        data: chartData.customers,
        backgroundColor: 'rgba(40, 167, 69, 0.6)',
      },
      {
        label: 'Orders',
        data: chartData.orders,
        backgroundColor: 'rgba(255, 193, 7, 0.6)',
      },
    ],
  };

  const lineChartData = {
    labels: chartData.labels,
    datasets: [
      {
        label: 'Products',
        data: chartData.products,
        borderColor: 'rgba(0, 123, 255, 1)',
        fill: false,
      },
      {
        label: 'Customers',
        data: chartData.customers,
        borderColor: 'rgba(40, 167, 69, 1)',
        fill: false,
      },
      {
        label: 'Orders',
        data: chartData.orders,
        borderColor: 'rgba(255, 193, 7, 1)',
        fill: false,
      },
    ],
  };

  if (loading) {
    return <div className="text-center mt-5">Loading...</div>;
  }

  return (
    <div className="d-flex">
      {/* Sidebar */}
      <div className="bg-dark text-white p-3" style={{ minHeight: '100vh', width: '200px' }}>
        <h4 className="text-center mb-4">
          <i className="bi bi-speedometer2 me-2"></i> Dashboard
        </h4>
        <ul className="nav flex-column">
          <li className="nav-item mb-2">
            <i className="bi bi-box-seam me-2"></i> View Products
          </li>
          <li className="nav-item mb-2">
            <i className="bi bi-people-fill me-2"></i> View Customers
          </li>
          <li className="nav-item mb-2">
            <i className="bi bi-cart-check-fill me-2"></i> View Orders
          </li>
          <li className="nav-item mb-2">
            <i className="bi bi-person-workspace me-2"></i> View Employees
          </li>
        </ul>
      </div>

      {/* Main Content */}
      <div className="flex-grow-1 p-4">
        <div className="row mb-4">
          <div className="col-md-3 mb-3">
            <div className="card text-white bg-primary h-100 shadow-sm">
              <div className="card-body d-flex flex-column justify-content-between">
                <div>
                  <i className="bi bi-box-seam fs-3"></i>
                  <h5 className="card-title mt-2">Total Products</h5>
                </div>
                <h3>{stats.products}</h3>
              </div>
            </div>
          </div>
          <div className="col-md-3 mb-3">
            <div className="card text-white bg-success h-100 shadow-sm">
              <div className="card-body d-flex flex-column justify-content-between">
                <div>
                  <i className="bi bi-people-fill fs-3"></i>
                  <h5 className="card-title mt-2">Total Customers</h5>
                </div>
                <h3>{stats.customers}</h3>
              </div>
            </div>
          </div>
          <div className="col-md-3 mb-3">
            <div className="card text-white bg-warning h-100 shadow-sm">
              <div className="card-body d-flex flex-column justify-content-between">
                <div>
                  <i className="bi bi-cart-check-fill fs-3"></i>
                                    <h5 className="card-title mt-2">Total Orders</h5>
                </div>
                <h3>{stats.orders}</h3>
              </div>
            </div>
          </div>
          <div className="col-md-3 mb-3">
            <div className="card text-white bg-dark h-100 shadow-sm">
              <div className="card-body d-flex flex-column justify-content-between">
                <div>
                  <i className="bi bi-person-workspace fs-3"></i>
                  <h5 className="card-title mt-2">Total Employees</h5>
                </div>
                <h3>{stats.employees}</h3>
              </div>
            </div>
          </div>
        </div>

        {/* Charts Section */}
        <div className="row">
          <div className="col-md-6 mb-4">
            <div className="card shadow-sm">
              <div className="card-body">
                <h5 className="card-title text-center">Bar Chart Overview</h5>
                <Bar data={barChartData} options={{ responsive: true }} />
              </div>
            </div>
          </div>
          <div className="col-md-6 mb-4">
            <div className="card shadow-sm">
              <div className="card-body">
                <h5 className="card-title text-center">Line Chart Overview</h5>
                <Line data={lineChartData} options={{ responsive: true }} />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ManagerDashboard;

 
