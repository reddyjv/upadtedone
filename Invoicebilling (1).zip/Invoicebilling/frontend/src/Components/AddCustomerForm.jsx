import { useState, useEffect } from 'react';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';

const AddCustomerForm = () => {
  const [formData, setFormData] = useState({
    cname: '',
    address: '',
    mailId: '',
    cphone: '',
    category: '',
  });

  const [formErrors, setFormErrors] = useState({});
  const [success, setSuccess] = useState('');
  const [error, setError] = useState('');
  const [isFormValid, setIsFormValid] = useState(false);

  // Live validation on every change
  useEffect(() => {
    validate();
  }, [formData]);

  useEffect(() => {
    if (success) {
      const timer = setTimeout(() => setSuccess(''), 5000);
      return () => clearTimeout(timer);
    }
  }, [success])

  const validate = () => {
    const errors = {};

    if (formData.cname==="") {
      errors.cname = 'Customer name is required.';
    }

    if (formData.address==="") {
      errors.address = 'Address is required.';
    }

    if (formData.mailId==="") {
      errors.mailId = 'Email is required.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.mailId)) {
      errors.mailId = 'Invalid email format.';
    }

    if (formData.cphone==="") {
      errors.cphone = 'Phone number is required.';
    } else if (!/^\d{10}$/.test(formData.cphone)) {
      errors.cphone = 'Phone number must be 10 digits.';
    }

    if (formData.category==="") {
      errors.category = 'Customer type is required.';
    }

    setFormErrors(errors);
    setIsFormValid(Object.keys(errors).length === 0);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    setFormErrors(prev => ({ ...prev, [name]: '' }));
    setSuccess('');
    setError('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!isFormValid) return;

    try {
      const res = await axios.post('http://localhost:5000/api/customers/add', formData);
      setSuccess(`✅ Customer added with ID: ${res.data.customer.customerId}`);
      setFormData({ cname: '', address: '', mailId: '', cphone: '', category: '' });
    } catch (err) {
      if(err.status===500){
        setError("Customer is already Registered");
      }
      else
      {
        setError(err.message)
      }
     
    }
  };

  return (
    <div className="container mt-5">
      <div className="card shadow-lg p-4 border-0 rounded-4" style={{ maxWidth: '720px', margin: '0 auto', background: '#f9fdfc' }}>
        <h3 className="text-center text-white py-3 rounded-top" style={{ background: 'linear-gradient(to right, #6a11cb, #2575fc)' }}>
          👤 Add New Customer
        </h3>

        {success && <div className="alert alert-success mt-3">{success}</div>}
        {error && <div className="alert alert-danger mt-3">{error}</div>}

        <form onSubmit={handleSubmit} noValidate>
          {[
            { label: 'Customer Name', name: 'cname', type: 'text', placeholder: 'Enter full name' },
            { label: 'Address', name: 'address', type: 'textarea', placeholder: 'Enter full address', rows: 2 },
            { label: 'Email ID', name: 'mailId', type: 'email', placeholder: 'example@mail.com' },
            { label: 'Phone Number', name: 'cphone', type: 'tel', placeholder: '10-digit mobile number' },
          ].map(({ label, name, type, placeholder, rows }) => (
            <div className="mb-3" key={name}>
              <label className="form-label fw-semibold">{label}</label>
              {type === 'textarea' ? (
                <textarea
                  className={`form-control ${formErrors[name] ? 'is-invalid' : ''}`}
                  name={name}
                  placeholder={placeholder}
                  value={formData[name]}
                  onChange={handleChange}
                  rows={rows}
                />
              ) : (
                <input
                  type={type}
                  className={`form-control ${formErrors[name] ? 'is-invalid' : ''}`}
                  name={name}
                  placeholder={placeholder}
                  value={formData[name]}
                  onChange={handleChange}
                />
              )}
              {formErrors[name] && <div className="invalid-feedback">{formErrors[name]}</div>}
            </div>
          ))}

          <div className="mb-4">
            <label className="form-label fw-semibold">Customer Type</label>
            <select
              name="category"
              className={`form-select ${formErrors.category ? 'is-invalid' : ''}`}
              value={formData.category}
              onChange={handleChange}
            >
              <option value="">-- Select Category --</option>
              <option value="Wholesale">Wholesale</option>
              <option value="Retailer">Retailer</option>
            </select>
            {formErrors.category && <div className="invalid-feedback">{formErrors.category}</div>}
          </div>

          <div className="d-grid">
            <button
              type="submit"
              className="btn btn-primary fw-bold"
              disabled={!isFormValid}
            >
              ➕ Add Customer
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddCustomerForm;
