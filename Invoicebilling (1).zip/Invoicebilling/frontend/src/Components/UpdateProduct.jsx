import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate, useParams } from 'react-router-dom';

const UpdateProduct = () => {
  const { productId } = useParams(); // Get productId from URL params
  const [product, setProduct] = useState({
    productId: '',
    pname: '',
    saleprice: '',
    MRP: '',
    stock: '',
    GST: '',
    batchNo: '',
    category: '',
  });
  product.productId=productId;
  const [loading, setLoading] = useState(true);
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  // Fetch product data from API
  useEffect(() => {
    axios
      .get(`http://localhost:5000/api/products/products/${productId}`)
      .then(res => {
        setProduct(res.data);
        setLoading(false);
      })
      .catch(err => {
        console.error('Error fetching product:', err);
        setLoading(false);
      });
  }, [productId]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setProduct({
      ...product,
      [name]: value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Simple validation checks
    let formErrors = {};
    if (!product.pname) formErrors.pname = 'Product name is required.';
    if (!product.saleprice || product.saleprice <= 0) formErrors.saleprice = 'Sale price must be a positive number.';
    if (!product.MRP || product.MRP <= 0) formErrors.MRP = 'MRP must be a positive number.';
    if (!product.stock || product.stock < 0) formErrors.stock = 'Stock cannot be negative.';
    if (!product.GST || product.GST < 0) formErrors.GST = 'GST cannot be negative.';
    if (!product.batchNo) formErrors.batchNo = 'Batch number is required.';
    if (!product.category) formErrors.category = 'Category is required.';
    
    setErrors(formErrors);

    // If no errors, proceed to submit the form
    if (Object.keys(formErrors).length === 0) {
      axios
        .put(`http://localhost:5000/api/products/products/${productId}`, product)
        .then(() => {
          alert('Product updated successfully!');
          navigate('/product-list'); // Redirect to product list after successful update
        })
        .catch(err => {
          console.error('Error updating product:', err);
          alert('Error updating product');
        });
    }
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  return (
    <div className="container mt-5">
      <h3 className="mb-4 text-center">Update Product</h3>
      <form onSubmit={handleSubmit} className="bg-light p-4 rounded shadow-sm">
        <div className="form-group">
          <label htmlFor="productId" className="form-label">Product ID</label>
          <input
            type="text"
            id="productId"
            className="form-control"
            value={product.productId}
            onChange={handleChange}
            disabled
          />
        </div>
        
        <div className="form-group">
          <label htmlFor="pname" className="form-label">Product Name</label>
          <input
            type="text"
            id="pname"
            className={`form-control ${errors.pname ? 'is-invalid' : ''}`}
            name="pname"
            value={product.pname}
            onChange={handleChange}
            placeholder="Enter product name"
          />
          {errors.pname && <div className="invalid-feedback">{errors.pname}</div>}
        </div>

        <div className="form-group">
          <label htmlFor="saleprice" className="form-label">Sale Price</label>
          <input
            type="number"
            id="saleprice"
            className={`form-control ${errors.saleprice ? 'is-invalid' : ''}`}
            name="saleprice"
            value={product.saleprice}
            onChange={handleChange}
            placeholder="Enter sale price"
          />
          {errors.saleprice && <div className="invalid-feedback">{errors.saleprice}</div>}
        </div>

        <div className="form-group">
          <label htmlFor="MRP" className="form-label">MRP</label>
          <input
            type="number"
            id="MRP"
            className={`form-control ${errors.MRP ? 'is-invalid' : ''}`}
            name="MRP"
            value={product.MRP}
            onChange={handleChange}
            placeholder="Enter MRP"
          />
          {errors.MRP && <div className="invalid-feedback">{errors.MRP}</div>}
        </div>

        <div className="form-group">
          <label htmlFor="stock" className="form-label">Stock</label>
          <input
            type="number"
            id="stock"
            className={`form-control ${errors.stock ? 'is-invalid' : ''}`}
            name="stock"
            value={product.stock}
            onChange={handleChange}
            placeholder="Enter stock quantity"
          />
          {errors.stock && <div className="invalid-feedback">{errors.stock}</div>}
        </div>

        <div className="form-group">
          <label htmlFor="GST" className="form-label">GST (%)</label>
          <input
            type="number"
            id="GST"
            className={`form-control ${errors.GST ? 'is-invalid' : ''}`}
            name="GST"
            value={product.GST}
            onChange={handleChange}
            placeholder="Enter GST percentage"
          />
          {errors.GST && <div className="invalid-feedback">{errors.GST}</div>}
        </div>

        <div className="form-group">
          <label htmlFor="batchNo" className="form-label">Batch No</label>
          <input
            type="text"
            id="batchNo"
            className={`form-control ${errors.batchNo ? 'is-invalid' : ''}`}
            name="batchNo"
            value={product.batchNo}
            onChange={handleChange}
            placeholder="Enter batch number"
          />
          {errors.batchNo && <div className="invalid-feedback">{errors.batchNo}</div>}
        </div>

        <div className="form-group">
          <label htmlFor="category" className="form-label">Category</label>
          <input
            type="text"
            id="category"
            className={`form-control ${errors.category ? 'is-invalid' : ''}`}
            name="category"
            value={product.category}
            onChange={handleChange}
            placeholder="Enter product category"
          />
          {errors.category && <div className="invalid-feedback">{errors.category}</div>}
        </div>

        <div className="text-center">
          <button type="submit" className="btn btn-primary px-4 py-2">
            Save Changes
          </button>
        </div>
        {JSON.stringify(product)}
      </form>
    </div>
  );
};

export default UpdateProduct;
