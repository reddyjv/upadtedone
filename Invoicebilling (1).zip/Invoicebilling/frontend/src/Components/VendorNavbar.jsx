import { NavLink, useNavigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import './navbar.css';  // Add custom styles here

const VendorNavbar = () => {
  const navigate = useNavigate();

  return (
    <div className="d-flex flex-column">
      {/* Navbar */}
      <nav className="navbar navbar-expand-lg navbar-dark custom-navbar px-3">
        <NavLink className="navbar-brand fw-bold" to="/">Vendor DashBoard</NavLink>
        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav ms-auto">
            <li className="nav-item"><NavLink className="nav-link" to="/user">Home</NavLink></li>
            <li className="nav-item"><NavLink className="nav-link" to="/add-product">Add Product</NavLink></li>
            <li className="nav-item"><NavLink className="nav-link" to="/products">List Products</NavLink></li>
            <li className="nav-item"><NavLink className="nav-link" to="/add-customer">Add Customer</NavLink></li>
            <li className="nav-item"><NavLink className="nav-link" to="/customers">List Customers</NavLink></li>
          </ul>
        </div>
      </nav>
    </div>
    );
};

export default VendorNavbar