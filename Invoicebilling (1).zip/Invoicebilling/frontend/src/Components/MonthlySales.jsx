import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Bar, Line, Pie } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  LineElement,
  PointElement,
  ArcElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js';

ChartJS.register(CategoryScale, LinearScale, BarElement, LineElement, PointElement, ArcElement, Title, Tooltip, Legend);

const insightOptions = [
  { key: 'monthly', label: '📅 Monthly Sale' },
  { key: 'yearly', label: '📆 Yearly Sale' },
  { key: 'payment', label: '💳 Payment Mode Sale' },
  { key: 'product', label: '📦 Product Wise Sale' },
  { key: 'daywise', label: '📈 Day-wise Sale' }
];

const AllInvoicesWithFilters = () => {
  const [invoices, setInvoices] = useState([]);
  const [selectedInsight, setSelectedInsight] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchInvoices = async () => {
      try {
        setLoading(true);
        const res = await axios.get('http://localhost:5000/api/invoices/all');
        setInvoices(res.data);
      } catch (err) {
        console.error('Failed to fetch invoices:', err);
        setError('Error fetching invoices');
      } finally {
        setLoading(false);
      }
    };

    fetchInvoices();
  }, []);

  const getChartData = () => {
    switch (selectedInsight) {
      case 'monthly': {
        const monthTotals = Array(12).fill(0);
        invoices.forEach(inv => {
          const [d, m] = inv.date?.split('/') || [];
          if (m && inv.totals?.finalAmount) {
            monthTotals[parseInt(m, 10) - 1] += inv.totals.finalAmount;
          }
        });

        const labels = [...Array(12)].map((_, i) => new Date(0, i).toLocaleString('default', { month: 'short' }));

        return { labels, data: monthTotals };
      }

      case 'yearly': {
        const yearTotals = {};
        invoices.forEach(inv => {
          const [, , y] = inv.date?.split('/') || [];
          if (y && inv.totals?.finalAmount) {
            yearTotals[y] = (yearTotals[y] || 0) + inv.totals.finalAmount;
          }
        });

        return {
          labels: Object.keys(yearTotals),
          data: Object.values(yearTotals)
        };
      }

      case 'payment': {
        const paymentModes = {};
        invoices.forEach(inv => {
          const mode = inv.totals.paymentMode || 'Unknown';
          paymentModes[mode] = (paymentModes[mode] || 0) + (inv.totals?.finalAmount || 0);
        });

        return {
          labels: Object.keys(paymentModes),
          data: Object.values(paymentModes)
        };
      }

      case 'product': {
        const productSales = {};
        invoices.forEach(inv => {
          inv.items.forEach(item => {
            productSales[item.pname] = (productSales[item.pname] || 0) + (item.qty * item.saleprice);
          });
        });

        return {
          labels: Object.keys(productSales),
          data: Object.values(productSales)
        };
      }

      case 'daywise': {
        const daySales = {};
        invoices.forEach(inv => {
          const [d, m, y] = inv.date?.split('/') || [];
          const fullDate = `${d}/${m}/${y}`;
          daySales[fullDate] = (daySales[fullDate] || 0) + (inv.totals?.finalAmount || 0);
        });

        return {
          labels: Object.keys(daySales),
          data: Object.values(daySales)
        };
      }

      default:
        return null;
    }
  };

  const chartData = getChartData();
  const totalSales = invoices.reduce((acc, inv) => acc + (inv.totals?.finalAmount || 0), 0);

  const commonChartDataset = (label, backgroundColor, borderColor) => ({
    label,
    data: chartData?.data,
    backgroundColor,
    borderColor,
    borderWidth: 2
  });

  return (
    <div className="container-fluid mt-4 mb-4">
      <div className="card shadow p-3">
        <div className="row">
          {/* Sidebar */}
          <div className="col-md-2">
            <h5 style={{ marginBottom: '22%' }} className="text-primary">📊 Insights</h5>
            {insightOptions.map(({ key, label }) => (
              <div
                key={key}
                onClick={() => setSelectedInsight(key)}
                className="p-2 mt-2 border border-primary rounded text-center insight-box"
                style={{ cursor: 'pointer' }}
              >
                {label}
              </div>
            ))}
          </div>

          {/* Main Content */}
          <div className="col-md-10 ps-4">
            {selectedInsight && chartData && (
              <>
                <h5 className="text-center mb-3 text-secondary">
                  {insightOptions.find(opt => opt.key === selectedInsight)?.label}
                </h5>

                {/* Charts */}
                <div className="row mb-4">
                  <div className="col-md-4">
                    <Bar
                      data={{
                        labels: chartData.labels,
                        datasets: [
                          commonChartDataset('Bar', 'rgba(54, 162, 235, 0.5)', 'rgba(54, 162, 235, 1)')
                        ]
                      }}
                      options={{ responsive: true }}
                    />
                  </div>
                  <div className="col-md-4">
                    <Line
                      data={{
                        labels: chartData.labels,
                        datasets: [
                          commonChartDataset('Line', 'rgba(153, 102, 255, 0.5)', 'rgba(153, 102, 255, 1)')
                        ]
                      }}
                      options={{ responsive: true }}
                    />
                  </div>
                  <div className="col-md-4">
                    <Pie
                      data={{
                        labels: chartData.labels,
                        datasets: [
                          {
                            label: 'Pie',
                            data: chartData.data,
                            backgroundColor: chartData.labels.map(
                              (_, i) =>
                                `hsl(${(i * 360) / chartData.labels.length}, 70%, 70%)`
                            )
                          }
                        ]
                      }}
                      options={{ responsive: true }}
                    />
                  </div>
                </div>

                {/* Summary Table */}
                <div className="table-responsive mt-4">
                  <table className="table table-bordered table-striped">
                    <thead className="table-primary">
                      <tr>
                        <th>Label</th>
                        <th>Amount (₹)</th>
                      </tr>
                    </thead>
                    <tbody>
                      {chartData.labels.map((label, i) => (
                        <tr key={i}>
                          <td>{label}</td>
                          <td>{chartData.data[i].toFixed(2)}</td>
                        </tr>
                      ))}
                    </tbody>
                    <tfoot>
                      <tr className="fw-bold">
                        <td>Total</td>
                        <td>₹ {chartData.data.reduce((a, b) => a + b, 0).toFixed(2)}</td>
                      </tr>
                    </tfoot>
                  </table>
                </div>

                <div className="text-end mt-3 fw-bold">
                  🔢 Grand Total Sales (all invoices): ₹ {totalSales.toFixed(2)}
                </div>
              </>
            )}

            {loading ? (
              <p className="text-center text-muted">Loading invoices...</p>
            ) : error ? (
              <p className="text-danger text-center">{error}</p>
            ) : null}
          </div>
        </div>
      </div>

      {/* Hover Effect Styling */}
      <style>{`
        .insight-box:hover {
          background-color: #e6f0ff;
          border-color:rgb(10, 58, 106);
        }
      `}</style>
    </div>
  );
};

export default AllInvoicesWithFilters;
