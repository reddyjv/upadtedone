import React, { useState } from 'react';
import CustomerLookup from './CustomerLookup';
import VendorNavbar from './VendorNavbar';
import ProductEntry from './ProductEntry';
import BillingSummary from './BillingSummary';
import './styles.css';


const BillingPanel = () => {
  const [customer, setCustomer] = useState(null);
  const [products, setProducts] = useState([]);
  const [resetCustomerForm, setResetCustomerForm] = useState(false);

  const handleResetAll = () => {
    setCustomer(null);
    setProducts([]);
    setResetCustomerForm(true);
    setTimeout(() => setResetCustomerForm(false), 100);
  };

  return (
    <>
    <VendorNavbar/>
    <div className="container-fluid mt-5">
      <CustomerLookup setCustomer={setCustomer} resetTrigger={resetCustomerForm}   />
      <ProductEntry products={products} customer={customer} setProducts={setProducts} onResetAll={handleResetAll} />
    </div>
    </>
  );
};

export default BillingPanel;
