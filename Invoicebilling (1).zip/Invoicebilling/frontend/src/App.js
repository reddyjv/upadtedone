import logo from "./logo.svg";
import "./App.css";
import 'bootstrap/dist/css/bootstrap.min.css';


import AddProductForm from "./Components/AddProductForm";
import ProductList from "./Components/ProductList";

// src/App.jsx
import { BrowserRouter as Router, Routes, Route, Form } from "react-router-dom";
import Navbar from "./Components/Navbar";
// Import your other components:
import CustomeBar from "./Components/CustomeBar";
import AddCustomerForm from "./Components/AddCustomerForm";
import CustomerList from "./Components/CustomerList";
import AllData from "./Components/AllData";
import HomePage from "./Components/HomePage";
import MonthlySales from "./Components/MonthlySales";
import BillingPanel from "./Components/BillingPanel";
import DueBills from "./Components/DueBills";
import UpdateProduct from "./Components/UpdateProduct";
import UpdateCustomer from "./Components/UpdateCustomer";
import ManageProducts from "./Components/ManageProducts";
import Register from "./Components/Register";
import ManagerDashboard from "./Components/ManagerDashboard";
import Login from "./Components/Login";
import ManNavbar from "./Components/ManNavbar"
import { useState } from "react";
import ManDashboard from "./Components/ManDasboard";

const App = () => {
  const [user, setUser] = useState(null)
  return (
    <Router>
      <div>
        <Routes>
          <Route path="/user" element={<HomePage />} />
          <Route path="/managerHome" element={<Navbar />} />
          <Route path="/add-product" element={<AddProductForm />} />
          <Route path="/products" element={<ProductList />} />
          <Route path="/add-customer" element={<AddCustomerForm />} />
          <Route path="/customers" element={<CustomerList />} />
          <Route path="/bill" element={<BillingPanel />} />
          <Route path="/monthlysales" element={<MonthlySales />} />
          <Route path="/allinvoices" element={<AllData />} />
          <Route path="/dueinvoices" element={<DueBills />} />
          <Route path="/updateproduct/:productId" element={<UpdateProduct />} />
          <Route path="/updatecustomer/:id" element={<UpdateCustomer />} />
          <Route path="/manageproducts" element={<ManageProducts />} />
          <Route path="/" element={<CustomeBar />} />
          <Route path="/register" element={<Register />} />
          <Route path="/login" element={<Login/>}/>
          <Route path="/dashboard1" element={<ManNavbar/>}/>
          <Route path="/dashboard5" element={<ManagerDashboard/>}/>
        </Routes>
      </div>
    </Router>
  );
};

export default App;
