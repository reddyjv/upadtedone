const mongoose = require('mongoose');

const customerSchema = new mongoose.Schema({
    customerId: { type: String, unique: true },
    cname: String,
    cphone:{ type: Number, unique: true },
    address:String,
    category:String,
    mailId:String,
    walletBal: { type: Number, default: 0 },
});

module.exports = mongoose.model('Customers', customerSchema);
