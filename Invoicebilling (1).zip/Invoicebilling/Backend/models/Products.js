const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
    productId: { type: String, unique: true },
    pname: String,
    saleprice: {
        type: Number,
        set: v => Math.round(v * 100) / 100 // always round to 2 decimals
    },
    MRP:Number,
    stock: Number,
    GST:Number,
    batchNo:String,
    category:String,
});

module.exports = mongoose.model('Product', productSchema);
