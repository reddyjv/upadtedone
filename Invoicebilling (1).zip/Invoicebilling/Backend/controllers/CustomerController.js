const Customer = require('../models/Customer');

// Helper function to generate next customerId
const generateCustomerId = async () => {
  const lastCustomer = await Customer.findOne().sort({ customerId: -1 });
  if (!lastCustomer) return 'C1000';

  const lastId = parseInt(lastCustomer.customerId.substring(1));
  return 'C' + (lastId + 1);
};

// Insert new customer
exports.addCustomer = async (req, res) => {
  try {
    const newCustomerId = await generateCustomerId();
    const newCustomer = new Customer({
      customerId: newCustomerId,
      ...req.body
    });

    const saved = await newCustomer.save();
    res.status(201).json({ message: 'Customer added successfully', customer: saved });
  } catch (err) {
    res.status(500).json({ error: 'Error adding customer', details: err.message });
  }
};

// Update customer by customerId
exports.updateCustomer = async (req, res) => {
  try {
    const updated = await Customer.findOneAndUpdate(
      { customerId: req.params.customerId },
      req.body,
      { new: true }
    );

    if (!updated) return res.status(404).json({ error: 'Customer not found' });
    res.json({ message: 'Customer updated successfully', customer: updated });
  } catch (err) {
    res.status(500).json({ error: 'Error updating customer', details: err.message });
  }
};

// Delete customer by customerId
exports.deleteCustomer = async (req, res) => {
  try {
    const deleted = await Customer.findOneAndDelete({ customerId: req.params.customerId });
    if (!deleted) return res.status(404).json({ error: 'Customer not found' });
    res.json({ message: 'Customer deleted successfully' });
  } catch (err) {
    res.status(500).json({ error: 'Error deleting customer', details: err.message });
  }
};


exports.getAllCustomers = async (req, res) => {
  const customers = await Customer.find();
  res.json(customers);
};

// Get customer by phone number
exports.getCustomerByPhone = async (req, res) => {
    try {
      const customer = await Customer.findOne({ cphone: req.params.phone });
      if (!customer) {
        return res.status(404).json({ error: 'Customer not found' });
      }
      res.json(customer);
    } catch (err) {
      res.status(500).json({ error: 'Error fetching customer', details: err.message });
    }
  };

  exports.getSpecificCustomer=async(req,res)=>{
    try{
      const custom=await Customer.findOne({customerId:req.params.id});
      if(!custom){
        return res.status(404).json({ error: 'Customer not found' });
      }
      res.json(custom)
    }
    catch{
      res.status(500).json({ error: 'Error fetching customer', details: err.message });
    }
  }

  // PUT /api/customers/updateWallet/:id
exports.updateWallet= async (req, res) => {
  const customerId = req.params.customerId;
  const { amount } = req.body;

  const customer = await Customer.findOne({customerId:customerId});
  if (!customer) return res.status(404).send('Customer not found');

  customer.walletBal = (customer.walletBal || 0) + parseFloat(amount);
  await customer.save();

  res.status(200).send({ message: 'Wallet updated', walletBalance: customer.walletBal });
}

exports.updateCustomer = async (req, res) => {
  try {
    const updated = await Customer.findOneAndUpdate(
      { customerId: req.params.id },
      { $set: req.body },
      { new: true }
    );
    if (!updated) return res.status(404).json({ message: 'Customer not found' });
    res.json(updated);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

  
