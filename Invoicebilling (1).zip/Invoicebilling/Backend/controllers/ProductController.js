
const Product = require('../models/Products');

let generateProductId = async () => {
  const lastProduct = await Product.findOne().sort({ productId: -1 });
  if (!lastProduct) return 'P1001';

  const lastIdNum = parseInt(lastProduct.productId.replace('P', '')) || 1000;
  return 'P' + (lastIdNum + 1);
};

exports.addProduct = async (req, res) => {
  try {
    const productId = await generateProductId();
    const { pname, saleprice, MRP,stock,GST,batchNo, category } = req.body;

    const newProduct = new Product({ productId, pname, saleprice, MRP,stock,GST, batchNo, category });
    await newProduct.save();

    res.status(201).json({ success: true, product: newProduct });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

exports.getAllProducts = async (req, res) => {
  const products = await Product.find();
  res.json(products);
};

exports.deleteProduct = async (req, res) => {
  try {
    const { id } = req.params;
    const deleted = await Product.findOneAndDelete({ productId: id });

    if (!deleted) {
      return res.status(404).json({ success: false, message: 'Product not found' });
    }

    res.json({ success: true, message: 'Product deleted' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// Update product by productId
exports.updateProduct = async (req, res) => {
  try {
    const { id } = req.params;
    const updatedData = req.body;

    const updated = await Product.findOneAndUpdate({ productId: id }, updatedData, { new: true });

    if (!updated) {
      return res.status(404).json({ success: false, message: 'Product not found' });
    }

    res.json({ success: true, product: updated });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};
