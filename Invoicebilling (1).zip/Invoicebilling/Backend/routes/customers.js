const express = require('express');
const router = express.Router();
const customerController=require('../controllers/CustomerController')

router.post('/add', customerController.addCustomer);
router.get('/', customerController.getAllCustomers);
router.get('/search/:phone',customerController.getCustomerByPhone)
router.put('/update/:customerId', customerController.updateCustomer);
router.delete('/delete/:customerId', customerController.deleteCustomer);
router.put('/updateWallet/:customerId',customerController.updateWallet);
router.put('/updatecustomer/:id',customerController.updateCustomer);
router.get('/getcust/:id',customerController.getSpecificCustomer);

module.exports=router